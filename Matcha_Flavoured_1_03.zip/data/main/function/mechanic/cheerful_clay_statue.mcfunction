tag @s add CheerfulStatuePending
schedule function main:mechanic/set_clear_weather 3s append