execute as @a[tag=!ExcludeFromXPRemoval] at @s run xp set @s 0 levels
execute as @a[tag=!ExcludeFromXPRemoval] at @s run xp set @s 0 points