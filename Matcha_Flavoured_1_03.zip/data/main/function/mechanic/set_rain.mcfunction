weather rain
advancement revoke @a[tag=MournfulStatuePending] only main:mechanics/mournful_clay_statue
tag @a[tag=MournfulStatuePending] remove MournfulStatuePending