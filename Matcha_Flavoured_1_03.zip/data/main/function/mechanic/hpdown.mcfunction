execute as @a[scores={deaths=1..,Hearts=22..}] at @s run scoreboard players remove @s Hearts 2
#execute as @a[scores={deaths=1..}] at @s run tag @s add AddingHearts
execute as @a[scores={deaths=1..,Hearts=20..}] at @s run function main:mechanic/set_max_hp
execute as @a[scores={deaths=1..}] at @s run scoreboard players set @s deaths 0