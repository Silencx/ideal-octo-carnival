tag @s add AnvilInteractionPending
schedule function main:mechanic/check_anvil_interaction_delayed 1t append
advancement revoke @s only main:mechanics/inventory_changed