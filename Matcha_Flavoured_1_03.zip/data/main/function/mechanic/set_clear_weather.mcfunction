weather clear
advancement revoke @a[tag=CheerfulStatuePending] only main:mechanics/cheerful_clay_statue
tag @a[tag=CheerfulStatuePending] remove CheerfulStatuePending