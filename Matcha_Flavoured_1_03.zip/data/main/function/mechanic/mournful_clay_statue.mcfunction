tag @s add MournfulStatuePending
schedule function main:mechanic/set_rain 3s append