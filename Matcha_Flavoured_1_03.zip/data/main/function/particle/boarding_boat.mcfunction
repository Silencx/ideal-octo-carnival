execute if entity @s if block ~ ~-.1 ~ water run execute as @s on vehicle run execute at @n[type=#minecraft:boat] run particle minecraft:splash ^0.75 ^.5 ^1 .1 .1 .1 1 5
execute if entity @s if block ~ ~-.1 ~ water run execute as @s on vehicle run execute at @n[type=#minecraft:boat] run particle minecraft:splash ^-0.75 ^.5 ^1 .1 .1 .1 1 5
execute if entity @s if block ~ ~-.1 ~ water run execute as @s on vehicle run execute at @n[type=#minecraft:boat] run particle minecraft:splash ^ ^.5 ^1 .1 .1 .1 1 5
advancement revoke @s only main:particle/boarding_boat