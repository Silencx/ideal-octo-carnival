execute as @a[tag=GlowJamPending] at @s run effect give @e[distance=0.1..50] minecraft:glowing 30 0 true
tag @a[tag=GlowJamPending] remove GlowJamPending