playsound minecraft:block.bell.resonate player @s ~ ~ ~ 2 1
tag @s add GlowCrumblePending
schedule function main:effects/soul_sight_apply_glow_60 48 append
advancement revoke @s only main:mechanics/glow_crumble_eaten