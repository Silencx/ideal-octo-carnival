playsound minecraft:block.bell.resonate player @s ~ ~ ~ 2 1
tag @s add GlowMashPending
schedule function main:effects/soul_sight_apply_glow_3 48 append
advancement revoke @s only main:mechanics/glow_mash_eaten