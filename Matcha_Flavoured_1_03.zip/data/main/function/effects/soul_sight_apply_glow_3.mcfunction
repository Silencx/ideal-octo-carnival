execute as @a[tag=GlowMashPending] at @s run effect give @e[distance=0.1..50] minecraft:glowing 3 0 true
tag @a[tag=GlowMashPending] remove GlowMashPending