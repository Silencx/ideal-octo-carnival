execute as @a[tag=GlowCrumblePending] at @s run effect give @e[distance=0.1..50] minecraft:glowing 60 0 true
tag @a[tag=GlowCrumblePending] remove GlowCrumblePending