#execute at @a run data modify entity @s TicksFrozen append value 140 (It wont let me :c)
effect give @s slowness 5 4 true
effect give @s darkness 5 0 true
damage @s 2 freeze