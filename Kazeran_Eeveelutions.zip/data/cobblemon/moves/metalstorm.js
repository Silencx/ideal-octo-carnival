{
  num: 22055,
  accuracy: 100,
  basePower: 25,
  category: "Special",
  name: "Metal Storm",
  pp: 5,
  priority: 0,
  type: "Psychic",
	multihit: [2, 5],
	overrideDefensiveStat: 'def',	
  flags: { protect: 1, mirror: 1, metronome: 1 },
  secondary: {
    chance: 30,
    boosts: { spd: -1 }, 
  },
  target: "normal"
}