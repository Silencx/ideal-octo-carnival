{
  num: 22054,
  accuracy: 100,
  basePower: 80,
  category: "Special",
  name: "Radiant Descent",
  pp: 10,
  priority: 0,
  type: "Dark",
  flags: { protect: 1, mirror: 1, metronome: 1 },
  secondary: {
    chance: 100,
    boosts: { def: -1, spd: -1 }
  },
  target: "normal"
}